package org.LickingHeights;

public class Main {

    public static void main(String[] args) {
	// write your code here

        System.out.println("We discussed about the different type of " +
                "runtime errors");

        System.out.println("There are semi-colon errors");

        System.out.println("Two kinds of bracket errors");

        System.out.println("which are either missing a matching pair,");
        System.out.println("or are in the wrong place");

        System.out.println("Typing commands that are not recognized because of spelling mistakes" +
                "or capitalization errors are also runtime errors");

    }

}
